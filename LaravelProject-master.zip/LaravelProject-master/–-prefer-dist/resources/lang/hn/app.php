<?php
return [
    'title' =>  'स्थानीयकरण उदाहरण'
];
