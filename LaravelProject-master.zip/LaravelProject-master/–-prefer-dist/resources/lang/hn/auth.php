<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'यह क्रिडेंटिअल मैच नहीं हुआ ',
    'throttle' => 'बहुत जयदा हो गया प्लीज कुछ देर के बाद प्रयास करे ',

];
