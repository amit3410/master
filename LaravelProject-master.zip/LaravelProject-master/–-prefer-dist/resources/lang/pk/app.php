<?php
return [
    'title' =>  'لوکلائزیشن مثال'
];
